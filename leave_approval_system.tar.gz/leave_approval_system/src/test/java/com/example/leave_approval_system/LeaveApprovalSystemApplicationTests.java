package com.example.leave_approval_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveApprovalSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
